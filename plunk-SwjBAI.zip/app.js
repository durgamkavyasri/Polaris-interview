var app = angular.module('plunker', []);
app.controller('MainCtrl',function($scope,$http)
{ 
 $http.get("https://jsonplaceholder.typicode.com/users")
    .then(function (response) 
    {
      $scope.usercards = response.data;
    });
$scope.userData= function(id)
{
  
  window.location="UserData.html";
}
 
})

